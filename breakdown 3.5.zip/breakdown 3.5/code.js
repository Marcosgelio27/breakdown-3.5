var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["f0e721f3-181e-4e48-99dc-ba79ca517941","d8d25f19-1177-4ff1-9086-adaf65b9bb9b","314f7913-70af-4b7a-890d-cb764257c1b5"],"propsByKey":{"f0e721f3-181e-4e48-99dc-ba79ca517941":{"name":"bola_1","sourceUrl":null,"frameSize":{"x":20,"y":20},"frameCount":1,"looping":true,"frameDelay":12,"version":"IKDXzzz9PfY0hR1qhL1aoTVXBnj7S4mL","loadedFromSource":true,"saved":true,"sourceSize":{"x":20,"y":20},"rootRelativePath":"assets/f0e721f3-181e-4e48-99dc-ba79ca517941.png"},"d8d25f19-1177-4ff1-9086-adaf65b9bb9b":{"name":"bola_2","sourceUrl":null,"frameSize":{"x":20,"y":20},"frameCount":1,"looping":true,"frameDelay":12,"version":"4yk0cDGvoKF.nm25vXx_r3U1nNkJ6G4Z","loadedFromSource":true,"saved":true,"sourceSize":{"x":20,"y":20},"rootRelativePath":"assets/d8d25f19-1177-4ff1-9086-adaf65b9bb9b.png"},"314f7913-70af-4b7a-890d-cb764257c1b5":{"name":"Bloco_mais","sourceUrl":null,"frameSize":{"x":30,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"Te_HEw2FMETtoNenvVnoBEQMEPIklGaS","loadedFromSource":true,"saved":true,"sourceSize":{"x":30,"y":30},"rootRelativePath":"assets/314f7913-70af-4b7a-890d-cb764257c1b5.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var perdeu = 0
var pontos = 0
var bola1 = 0
var bola3 = 0
var bloco1 = 1
var inicio = 0
var bola_con = 0

 var bola = createSprite(200,320,20,20)
 bola.shapeColor = "green"
 bola.setAnimation("bola_1")

 var raquete = createSprite(200,380,75,10)
 raquete.shapeColor = "red"

 var bola2 = createSprite(150,175,20,20)
 bola2.visible = 0
 bola2.setAnimation("bola_2")
 
 var bola3 = createSprite(150,175,20,20)
 bola3.visible = 0
 bola3.setAnimation("bola_2")
 
var bloco1fileira1 = createSprite(20,50,30,30)
bloco1fileira1.shapeColor = "red"
var bloco2fileira1 = createSprite(60,50,30,30)
bloco2fileira1.shapeColor = "red"
var bloco3fileira1 = createSprite(100,50,30,30)
bloco3fileira1.shapeColor = "red"
var bloco4fileira1 = createSprite(140,50,30,30)
bloco4fileira1.shapeColor = "red"
var bloco5fileira1 = createSprite(180,50,30,30)
bloco5fileira1.shapeColor = "red"
var bloco6fileira1 = createSprite(220,50,30,30)
bloco6fileira1.shapeColor = "red"
var bloco7fileira1 = createSprite(260,50,30,30)
bloco7fileira1.shapeColor = "red"
var bloco8fileira1 = createSprite(300,50,30,30)
bloco8fileira1.shapeColor = "red"
var bloco9fileira1 = createSprite(340,50,30,30)
bloco9fileira1.shapeColor = "red"
var bloco10fileira1 = createSprite(380,50,30,30)
bloco10fileira1.shapeColor = "red"

var bloco1fileira2 = createSprite(40,100,30,30)
bloco1fileira2.shapeColor = "blue"
var bloco2fileira2 = createSprite(80,100,30,30)
bloco2fileira2.shapeColor = "blue"
var bloco3fileira2 = createSprite(120,100,30,30)
bloco3fileira2.shapeColor = "blue"
var bloco4fileira2 = createSprite(160,100,30,30)
bloco4fileira2.shapeColor = "blue"
var bloco5fileira2 = createSprite(200,100,30,30)
bloco5fileira2.shapeColor = "blue"
var bloco6fileira2 = createSprite(240,100,30,30)
bloco6fileira2.shapeColor = "blue"
var bloco7fileira2 = createSprite(280,100,30,30)
bloco7fileira2.shapeColor = "blue"
var bloco8fileira2 = createSprite(320,100,30,30)
bloco8fileira2.shapeColor = "blue"
var bloco9fileira2 = createSprite(360,100,30,30)
bloco9fileira2.shapeColor = "blue"

var bloco1fileira3 = createSprite(20,150,30,30)
bloco1fileira3.shapeColor = "red"
var bloco2fileira3 = createSprite(60,150,30,30)
bloco2fileira3.setAnimation("Bloco_mais")
var bloco3fileira3 = createSprite(100,150,30,30)
bloco3fileira3.shapeColor = "red"
var bloco4fileira3 = createSprite(140,150,30,30)
bloco4fileira3.shapeColor = "red"
var bloco5fileira3 = createSprite(180,150,30,30)
bloco5fileira3.shapeColor = "red"
var bloco6fileira3 = createSprite(220,150,30,30)
bloco6fileira3.shapeColor = "red"
var bloco7fileira3 = createSprite(260,150,30,30)
bloco7fileira3.shapeColor = "red"
var bloco8fileira3 = createSprite(300,150,30,30)
bloco8fileira3.shapeColor = "red"
var bloco9fileira3 = createSprite(340,150,30,30)
bloco9fileira3.shapeColor = "red"
var bloco10fileira3 = createSprite(380,150,30,30)
bloco10fileira3.shapeColor = "red"

var bloco1fileira4 = createSprite(40,200,30,30)
bloco1fileira4.shapeColor = "blue"
var bloco2fileira4 = createSprite(80,200,30,30)
bloco2fileira4.shapeColor = "blue"
var bloco3fileira4 = createSprite(120,200,30,30)
bloco3fileira4.shapeColor = "blue"
var bloco4fileira4 = createSprite(160,200,30,30)
bloco4fileira4.setAnimation("Bloco_mais")
var bloco5fileira4 = createSprite(200,200,30,30)
bloco5fileira4.shapeColor = "blue"
var bloco6fileira4 = createSprite(240,200,30,30)
bloco6fileira4.shapeColor = "blue"
var bloco7fileira4 = createSprite(280,200,30,30)
bloco7fileira4.shapeColor = "blue"
var bloco8fileira4 = createSprite(320,200,30,30)
bloco8fileira4.shapeColor = "blue"
var bloco9fileira4 = createSprite(360,200,30,30)
bloco9fileira4.shapeColor = "blue"


function draw(){
 background("skyblue")
 drawSprites()
 createEdgeSprites()
 
 textSize(23)
 fill("green")
 text("pontos: " +pontos,300,30)

 
 bola.bounceOff(topEdge)
 bola.bounceOff(rightEdge)
 bola.bounceOff(leftEdge)
 bola.bounceOff(raquete)
 bola2.bounceOff(topEdge)
 bola2.bounceOff(rightEdge)
 bola2.bounceOff(leftEdge)
 bola2.bounceOff(raquete)
 bola3.bounceOff(topEdge)
 bola3.bounceOff(rightEdge)
 bola3.bounceOff(leftEdge)
 bola3.bounceOff(raquete)
 if(inicio==1){
  raquete.x = World.mouseX
 }
 if(inicio==0){
  textSize(30)
  text("aperte espaco",100,285)
 }

 //fileira 1
 if(bola.isTouching(bloco1fileira1)){
   bloco1fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
   }
  if(bola.isTouching(bloco2fileira1)){
   bola.bounceOff(bloco2fileira1)
   bloco2fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
  if(bola.isTouching(bloco3fileira1)){
   bola.bounceOff(bloco3fileira1)
   bloco3fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
  }
  if(bola.isTouching(bloco4fileira1)){
   bola.bounceOff(bloco4fileira1)
   bloco4fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
  if(bola.isTouching(bloco5fileira1)){
   bola.bounceOff(bloco5fileira1)
   bloco5fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
  if(bola.isTouching(bloco6fileira1)){
   bola.bounceOff(bloco6fileira1)
   bloco6fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
  if(bola.isTouching(bloco7fileira1)){
   bola.bounceOff(bloco7fileira1)
   bloco7fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
  if(bola.isTouching(bloco8fileira1)){
   bola.bounceOff(bloco8fileira1)
   bloco8fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
  if(bola.isTouching(bloco9fileira1)){
   bola.bounceOff(bloco9fileira1)
   bloco9fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
   if(bola.isTouching(bloco10fileira1)){
   bola.bounceOff(bloco10fileira1)
   bloco10fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
 //fileira2
 if(bola.isTouching(bloco1fileira2)){
   bola.bounceOff(bloco1fileira2)
   bloco1fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
  if(bola.isTouching(bloco2fileira2)){
   bola.bounceOff(bloco2fileira2)
   bloco2fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
  if(bola.isTouching(bloco3fileira2)){
   bola.bounceOff(bloco3fileira2)
   bloco3fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
  if(bola.isTouching(bloco4fileira2)){
   bola.bounceOff(bloco4fileira2)
   bloco4fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
  if(bola.isTouching(bloco5fileira2)){
   bola.bounceOff(bloco5fileira2)
   bloco5fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
  if(bola.isTouching(bloco6fileira2)){
   bola.bounceOff(bloco6fileira2)
   bloco6fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
  if(bola.isTouching(bloco7fileira2)){
   bola.bounceOff(bloco7fileira2)
   bloco7fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
  if(bola.isTouching(bloco8fileira2)){
   bola.bounceOff(bloco8fileira2)
   bloco8fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
  if(bola.isTouching(bloco9fileira2)){
   bola.bounceOff(bloco9fileira2)
   bloco9fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
 //fileira 3
  if(bola.isTouching(bloco1fileira3)){
   bola.bounceOff(bloco1fileira3)
   bloco1fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
  if(bola.isTouching(bloco2fileira3)|| bola2.isTouching(bloco2fileira3)){
   bola2.bounceOff(bloco2fileira3)
   bola.bounceOff(bloco2fileira3)
   bloco2fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
   var roll2 = randomNumber(1, 2)
   if(roll2==1){
  bola3.shapeColor = "yellow"
  bola3.visible = 1
  bola3.velocityX = 6
  bola3.velocityY = 6
   } 
  roll2 = 7
 }
  if(bola.isTouching(bloco3fileira3)){
   bola.bounceOff(bloco3fileira3)
   bloco3fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
  if(bola.isTouching(bloco4fileira3)){
   bola.bounceOff(bloco4fileira3)
   bloco4fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
  if(bola.isTouching(bloco5fileira3)){
   bola.bounceOff(bloco5fileira3)
   bloco5fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
  if(bola.isTouching(bloco6fileira3)){
   bola.bounceOff(bloco6fileira3)
   bloco6fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
  if(bola.isTouching(bloco7fileira3)){
   bola.bounceOff(bloco7fileira3)
   bloco7fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
  if(bola.isTouching(bloco8fileira3)){
   bola.bounceOff(bloco8fileira3)
   bloco8fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
  if(bola.isTouching(bloco9fileira3)){
   bola.bounceOff(bloco9fileira3)
   bloco9fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
   if(bola.isTouching(bloco10fileira3)){
   bola.bounceOff(bloco10fileira3)
   bloco10fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0,25
 }
 //fileira 4
  
 if(bola.isTouching(bloco1fileira4)){
   bola.bounceOff(bloco1fileira4)
   bloco1fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0.2
 }
  if(bola.isTouching(bloco2fileira4)){
   bola.bounceOff(bloco2fileira4)
   bloco2fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0.2
 }
  if(bola.isTouching(bloco3fileira4)){
   bola.bounceOff(bloco3fileira4)
   bloco3fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0.2
 }
  if(bola.isTouching(bloco4fileira4) & bloco1 == 1){
   bloco1 = bloco1 -1
   bola.bounceOff(bloco4fileira4)
   bloco4fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
   bola.velocityY = bola.velocityY +0.2
   var roll = randomNumber(1, 2)
   if(roll==1){
  bola2.shapeColor = "yellow"
  bola2.visible = 1
  bola2.velocityX = 6
  bola2.velocityY = 6
   } 
  roll = 7
 }
  if(bola.isTouching(bloco5fileira4)){
   bola.bounceOff(bloco5fileira4)
   bloco5fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola.isTouching(bloco6fileira4)){
   bola.bounceOff(bloco6fileira4)
   bloco6fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola.isTouching(bloco7fileira4)){
   bola.bounceOff(bloco7fileira4)
   bloco7fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola.isTouching(bloco8fileira4)){
   bola.bounceOff(bloco8fileira4)
   bloco8fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola.isTouching(bloco9fileira4)){
   bola.bounceOff(bloco9fileira4)
   bloco9fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
 //bola 2 fileira 1
 if(bola2.isTouching(bloco1fileira1)){
   bola2.bounceOff(bloco1fileira1)
   bloco1fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
 if(bola2.isTouching(bloco2fileira1)){
   bola2.bounceOff(bloco2fileira1)
   bloco2fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco3fileira1)){
   bola2.bounceOff(bloco3fileira1)
   bloco3fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco4fileira1)){
   bola2.bounceOff(bloco4fileira1)
   bloco4fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco5fileira1)){
   bola2.bounceOff(bloco5fileira1)
   bloco5fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco6fileira1)){
   bola2.bounceOff(bloco6fileira1)
   bloco6fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco7fileira1)){
   bola2.bounceOff(bloco7fileira1)
   bloco7fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco8fileira1)){
   bola2.bounceOff(bloco8fileira1)
   bloco8fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco9fileira1)){
   bola2.bounceOff(bloco9fileira1)
   bloco9fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
   if(bola2.isTouching(bloco10fileira1)){
   bola2.bounceOff(bloco10fileira1)
   bloco10fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
 //fileira2
 if(bola2.isTouching(bloco1fileira2)){
   bola2.bounceOff(bloco1fileira2)
   bloco1fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco2fileira2)){
   bola2.bounceOff(bloco2fileira2)
   bloco2fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco3fileira2)){
   bola2.bounceOff(bloco3fileira2)
   bloco3fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco4fileira2)){
   bola2.bounceOff(bloco4fileira2)
   bloco4fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco5fileira2)){
   bola2.bounceOff(bloco5fileira2)
   bloco5fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco6fileira2)){
   bola2.bounceOff(bloco6fileira2)
   bloco6fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco7fileira2)){
   bola2.bounceOff(bloco7fileira2)
   bloco7fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco8fileira2)){
   bola2.bounceOff(bloco8fileira2)
   bloco8fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco9fileira2)){
   bola2.bounceOff(bloco9fileira2)
   bloco9fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
 //fileira 3
  if(bola2.isTouching(bloco1fileira3)){
   bola2.bounceOff(bloco1fileira3)
   bloco1fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco2fileira3)){
   bola2.bounceOff(bloco2fileira3)
   bloco2fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco3fileira3)){
   bola2.bounceOff(bloco3fileira3)
   bloco3fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco4fileira3)){
   bola2.bounceOff(bloco4fileira3)
   bloco4fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco5fileira3)){
   bola2.bounceOff(bloco5fileira3)
   bloco5fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco6fileira3)){
   bola2.bounceOff(bloco6fileira3)
   bloco6fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco7fileira3)){
   bola2.bounceOff(bloco7fileira3)
   bloco7fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco8fileira3)){
   bola2.bounceOff(bloco8fileira3)
   bloco8fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco9fileira3)){
   bola2.bounceOff(bloco9fileira3)
   bloco9fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
   if(bola2.isTouching(bloco10fileira3)){
   bola2.bounceOff(bloco10fileira3)
   bloco10fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
 //fileira 4
  
 if(bola2.isTouching(bloco1fileira4)){
   bola2.bounceOff(bloco1fileira4)
   bloco1fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco2fileira4)){
   bola2.bounceOff(bloco2fileira4)
   bloco2fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco3fileira4)){
   bola2.bounceOff(bloco3fileira4)
   bloco3fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco4fileira4)){
   bola2.bounceOff(bloco4fileira4)
   bloco4fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco5fileira4)){
   bola2.bounceOff(bloco5fileira4)
   bloco5fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco6fileira4)){
   bola2.bounceOff(bloco6fileira4)
   bloco6fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco7fileira4)){
   bola2.bounceOff(bloco7fileira4)
   bloco7fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco8fileira4)){
   bola2.bounceOff(bloco8fileira4)
   bloco8fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola2.isTouching(bloco9fileira4)){
   bola2.bounceOff(bloco9fileira4)
   bloco9fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
 
 //bola 3 fileira 1
 if(bola3.isTouching(bloco2fileira1)){
   bola3.bounceOff(bloco2fileira1)
   bloco2fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco3fileira1)){
   bola3.bounceOff(bloco3fileira1)
   bloco3fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco4fileira1)){
   bola3.bounceOff(bloco4fileira1)
   bloco4fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco5fileira1)){
   bola3.bounceOff(bloco5fileira1)
   bloco5fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco6fileira1)){
   bola3.bounceOff(bloco6fileira1)
   bloco6fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco7fileira1)){
   bola3.bounceOff(bloco7fileira1)
   bloco7fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco8fileira1)){
   bola3.bounceOff(bloco8fileira1)
   bloco8fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco9fileira1)){
   bola3.bounceOff(bloco9fileira1)
   bloco9fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
   if(bola3.isTouching(bloco10fileira1)){
   bola3.bounceOff(bloco10fileira1)
   bloco10fileira1.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
 //fileira2
 if(bola3.isTouching(bloco1fileira2)){
   bola3.bounceOff(bloco1fileira2)
   bloco1fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco2fileira2)){
   bola3.bounceOff(bloco2fileira2)
   bloco2fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco3fileira2)){
   bola3.bounceOff(bloco3fileira2)
   bloco3fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco4fileira2)){
   bola3.bounceOff(bloco4fileira2)
   bloco4fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco5fileira2)){
   bola3.bounceOff(bloco5fileira2)
   bloco5fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco6fileira2)){
   bola3.bounceOff(bloco6fileira2)
   bloco6fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco7fileira2)){
   bola3.bounceOff(bloco7fileira2)
   bloco7fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco8fileira2)){
   bola3.bounceOff(bloco8fileira2)
   bloco8fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco9fileira2)){
   bola3.bounceOff(bloco9fileira2)
   bloco9fileira2.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
 //fileira 3
  if(bola3.isTouching(bloco1fileira3)){
   bola3.bounceOff(bloco1fileira3)
   bloco1fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco2fileira3)){
   bola3.bounceOff(bloco2fileira3)
   bloco2fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco3fileira3)){
   bola3.bounceOff(bloco3fileira3)
   bloco3fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco4fileira3)){
   bola3.bounceOff(bloco4fileira3)
   bloco4fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco5fileira3)){
   bola3.bounceOff(bloco5fileira3)
   bloco5fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco6fileira3)){
   bola3.bounceOff(bloco6fileira3)
   bloco6fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco7fileira3)){
   bola3.bounceOff(bloco7fileira3)
   bloco7fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco8fileira3)){
   bola3.bounceOff(bloco8fileira3)
   bloco8fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco9fileira3)){
   bola3.bounceOff(bloco9fileira3)
   bloco9fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
   if(bola3.isTouching(bloco10fileira3)){
   bola3.bounceOff(bloco10fileira3)
   bloco10fileira3.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
 //fileira 4
  
 if(bola3.isTouching(bloco1fileira4)){
   bola3.bounceOff(bloco1fileira4)
   bloco1fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco2fileira4)){
   bola3.bounceOff(bloco2fileira4)
   bloco2fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco3fileira4)){
   bola3.bounceOff(bloco3fileira4)
   bloco3fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco4fileira4)){
   bola3.bounceOff(bloco4fileira4)
   bloco4fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco5fileira4)){
   bola3.bounceOff(bloco5fileira4)
   bloco5fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco6fileira4)){
   bola3.bounceOff(bloco6fileira4)
   bloco6fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco7fileira4)){
   bola3.bounceOff(bloco7fileira4)
   bloco7fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco8fileira4)){
   bola3.bounceOff(bloco8fileira4)
   bloco8fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
  if(bola3.isTouching(bloco9fileira4)){
   bola3.bounceOff(bloco9fileira4)
   bloco9fileira4.destroy()
   pontos = pontos +1
   playSound("assets/category_hits/8bit_splat.mp3");
 }
 
 if(pontos==38){
   
   bola.destroy()
   bola2.destroy()
   bola3.destroy()
   raquete.destroy()
   textSize(50)
   fill("red")
   text("você ganhou", 60, 200)
   if(perdeu==0){
   playSound("assets/category_achievements/melodic_win_1.mp3");
   } 
  perdeu = perdeu +1
   }
   
 if(bola2.visible == 1 & bola_con == 0){
 if(bola.y>400 & bola2.y>400){
   bola.destroy()
   raquete.destroy()
   textSize(50)
   fill("red")
   text("você perdeu", 60, 300)
   if(perdeu==0){
   playSound("assets/category_alerts/vibrant_game_negative_bling_1.mp3");
   }
   perdeu=perdeu+1
 }
 }
 
 if(bola2.visible == 0){
 if(bola.y>400){
   bola.destroy()
   raquete.destroy()
   textSize(50)
   fill("red")
   text("você perdeu", 60, 300)
   if(perdeu==0){
   playSound("assets/category_alerts/vibrant_game_negative_bling_1.mp3");
   }
   perdeu=perdeu+1
 }
 }
 if(bola2.visible == 1 & bola3.visible == 1){
   bola_con == 1
 if(bola.y>400 & bola2.y>400 & bola3.y>400){
   bola.destroy()
   raquete.destroy()
   textSize(50)
   fill("red")
   text("você perdeu️", 60, 300)
   if(perdeu==0){
   playSound("assets/category_alerts/vibrant_game_negative_bling_1.mp3");
   }
   perdeu=perdeu+1
 }
 }
 
 if(keyDown("space") & inicio == 0){
   bola.velocityY = 4
   bola.velocityX = 4
   inicio = inicio +1
 }
 
 
} 



// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
